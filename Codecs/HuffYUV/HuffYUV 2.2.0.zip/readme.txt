This is Huffyuv v2.2.0, by Ben Rudiak-Gould and Klaus Post.
(If the archive you downloaded has an older version number, 
it's because you followed an outdated link.)

This source code is Copyright 2000 Ben Rudiak-Gould.  It is distributed
under the terms of the GNU General Public License, version 2 or later.
You should have received a copy of the GPL along with this source code;
if not, see http://www.gnu.org/copyleft/gpl.html or the Huffyuv home
page, http://www.math.berkeley.edu/~benrg/huffyuv.html .

I have tested this code only under Visual C++ 6.0.

If you find this source code useful or you have problems, please let
me know!  My email address is benrg@math.berkeley.edu.
