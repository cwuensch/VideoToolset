This is Huffyuv v2.1.1, by Ben Rudiak-Gould.  (If the archive you
downloaded has an older version number, it's because you followed an
outdated link.)

This software is Copyright 2000 Ben Rudiak-Gould.  For information,
distribution conditions, and full source code please visit the Huffyuv
home page at http://www.math.berkeley.edu/~benrg/huffyuv.html .

To install Huffyuv, right click on huffyuv.inf and select "Install."
