=====================================================
 LTSLP(): "LimitedTemporalSoften, LowPass-protected"
=====================================================
===
required plugins:

Masktools.dll -> http://manao4.free.fr/MaskTools-v1.5.8.zip
RemoveGrain.dll from RemoveGrain 1.0 pre -> http://home.arcor.de/kassandro/RemoveGrain/RemoveGrain.rar
===
default call:

LTSLP(	frames=2, threshY=23, threshC=23, maxvar=23, TSmode=2,
 \	limitY=2, limitC=2, radius=2.0, cl1=0, cl2=0)
===
description:

Basically a normal TemporalSoften(), with some additional twists.
Normal TemporalSoften(), with low thresholds, doesn't catch all noise. With high thresholds, it kills detail, and creates smearing & banding.
LTSLP allows *much* higher thresholds, thus catching all noise, while keeping more detail, and creating very little smearing or banding. (High limits will flatten down moving parts, though.)
===
parameters:

# frames  = default(2)	#\
# threshY = default(23)	#|
# threshC = default(23)	#|- exactly the same parameters as in normal TemporalSoften().
# maxvar  = default(23)	#|  (thresh's & maxvar may be this high and even more, 
# TSmode  = default(2)	#/   because of the limiting and the lowpass protection)
# limitY  = default(2)	# - maximum pixel change to luma plane (but: plus 'cl2')
# limitC  = default(2)	# - maximum pixel change to chroma plane
# radius  = default(2.0)# - lowpass protection: radius for gaussian blur
			#   (smaller radius -> less smearing, but less NR / and vice versa)
# cl1     = default(0)	# - pre-calming (luma only) by limited clense(). This is also lowpass protected.
# cl2     = default(0)	# - post-calming (luma only) by limited clense(). This is NOT lowpass protected, hence may smear.!