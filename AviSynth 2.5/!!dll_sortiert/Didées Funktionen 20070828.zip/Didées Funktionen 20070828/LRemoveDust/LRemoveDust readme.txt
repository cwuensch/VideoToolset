=============
 LRemoveDust
=============
===
required plugins:

Masktools.dll -> http://manao4.free.fr/MaskTools-v1.5.8.zip
RemoveGrain.dll von RemoveGrain 1.0 pre -> http://home.arcor.de/kassandro/RemoveGrain/RemoveGrain.rar
Repair.dll from RemoveGrain 0.9 (!) -> www.RemoveGrain.de.tf
SSETools.dll from RemoveGrain 0.9 -> http://www.removegrain.de.tf/
===
default call:

LRemoveDust_mt:
LRemoveDust(4, limit=4, limitC=0)

LRemoveDust_SSEt:
LRemoveDust(4, 2, limit=4, limitU=255)
===
description:

not available
===
parameters:

not available