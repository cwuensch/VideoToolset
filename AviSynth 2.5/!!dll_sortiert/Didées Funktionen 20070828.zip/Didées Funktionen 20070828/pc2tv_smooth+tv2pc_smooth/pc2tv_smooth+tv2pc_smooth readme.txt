===========================
 pc2tv_smooth+tv2pc_smooth
===========================
===
required plugins:

RemoveGrain.dll from RemoveGrain 1.0 pre -> http://home.arcor.de/kassandro/RemoveGrain/RemoveGrain.rar
Masktools.dll -> http://manao4.free.fr/MaskTools-v1.5.8.zip
===
default call:

pc2tv_smooth()

tv2pc_smooth()
===
description:

not available
===
parameters:

not available