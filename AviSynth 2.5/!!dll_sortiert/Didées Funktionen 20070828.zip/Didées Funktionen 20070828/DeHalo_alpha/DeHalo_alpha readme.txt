==============
 DeHalo_alpha
==============
===
required plugins:

DeHalo_alpha_mt2:
Masktools.dll -> http://manao4.free.fr/MaskTools-v1.5.8.zip
Repair.dll from RemoveGrain 0.9 (!) -> www.RemoveGrain.de.tf
===
default call:

DeHalo_alpha(rx=2.0, ry=2.0, darkstr=1.0, brightstr=1.0, lowsens=50, highsens=50, ss=1.5)
===
description:

The following proof-of-concept function uses a method that I had in mind for a longer time already, but never actually tried it ... because during theorising I always thought "nah, this way it can't work. Well, I should have tried it earlier ... this is probably not the worst Halo remover ever seen

Currently, there are the following parameters:

- rx, ry [float, 1.0 ... 2.0 ... ~3.0]
As usual, the radii for halo removal.
Note: this function is rather sensitive to the radius settings. Set it as low as possible! If radius is set too high, it will start missing small spots.

- darkkstr, brightstr [float, 0.0 ... 1.0] [<0.0 and >1.0 possible]
The strength factors for processing dark and bright halos. Default 1.0 both for symmetrical processing. On Comic/Anime, darkstr=0.4~0.8 sometimes might be better ... sometimes. In General, the function seems to preserve dark lines rather good.

- lowsens, highsens [int, 0 ... 50 ... 100]
Sensitivity settings, not that easy to describe them exactly ... in a sense, they define a window between how weak an achieved effect has to be to get fully accepted, and how strong an achieved effect has to be to get fully discarded.
Defaults are 50 and 50 ... try and see for yourself.

- ss [float, 1.0 ... 1.5 ...]
Supersampling factor, to avoid creation of aliasing.
