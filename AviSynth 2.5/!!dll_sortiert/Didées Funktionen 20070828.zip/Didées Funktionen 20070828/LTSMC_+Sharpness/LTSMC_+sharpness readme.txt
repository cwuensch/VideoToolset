==================
 LTSMC_+sharpness
==================
===
required plugins:

RemoveGrain.dll from RemoveGrain 1.0 pre -> http://home.arcor.de/kassandro/RemoveGrain/RemoveGrain.rar
Repair.dll from RemoveGrain 0.9 (!) -> www.RemoveGrain.de.tf
Masktools.dll -> http://manao4.free.fr/MaskTools-v1.5.8.zip
MVTools -> http://www.avisynth.org/fizick/mvtools/
===
default call:

LTSMC(	frames=2, limitY=5.0, limitC=2.0, thY=24, thC=12, MCmode=2, APmode=3, \
	blcksze=16, chromaME=false, LPrad=3.3, hardlimit=1, double_proc=false, \
	frames2=2, Arad=4.0, Apow=1.4, Apow2=16.0, sharpness=80, show=0) #lmbda=???
===
description:

not available
===
parameters:

# frames	= 2	# distance of frames to consider, as usual for any temporal-soften
# limitY	= 5	# limits of real denoising for Y and UV.  limit > 0 uses absolut limiting.  
# limitC	= 2	# limit < 0 uses inverse power reduction, e.g. -2 --> sqrt(difference(input,denoised))
# thY		= 24	# thresholds of maximum pixel difference to still be included into pixel averaing.
# thC		= 12	# Can be set fairly high, since the limiting will (mostly) avoid serious artefacts.

# MCmode	= 2	# 1=search all vectors between distance frames directly (Manao's "efficace" function)
			# 2=search only vectors for frames N-1 & N+1, and do chained compensation for frames N2 & N3
			# no more available -->  #  3=first do both 1 & 2, then use the (probably) least distorted pixel of both. SLOOOW!!!
			# no more available -->  #  4= simple blend of 1 & 2
# APmode	= 3	# Strength of artefact protection: 1=weakest, 4=strongest. 0 disables
# blcksze	= 16	# blocksize for motion search: 16 (fast), 8 (slower) or 4 (patience)
# lmbda		= default( lmbda, select((blcksze/4), 0, 2500, 900, 0, 300)) # coherence of motion vector field
# chromaME	= false # do additional motion search on chroma planes. Slow.

# LPrad		= 3.3	# radius for denoising lowpass filter. rad=0 disables lowpass filtering.
# hardlimit	= 1	# apply clense() at the very end (w/o MC), but change no pixel more than this. 0 disables.
# double_proc	= false	# activate a 2nd stage of denoising. 
			# ( Currently ONLY AVAILABLE WITH MCmode=2 !!! )
# frames2	= 2	# distance of frames for 2nd-stage of temporal denoising, if activated through "double_proc"

# Arad		= 4.0	# radius of gaussian blur used for noise reduction of motion analyze clip
# Apow		= 1.4	# inverse power (^) of blur difference to apply to the analyzer. Apow is applied to small
# Apow2		= 16	# differences, Apow2 to big differences. 
				# Apow < 0 --> use absolut limiting instead of inverse power. Apow2 then is not used. 
				# NOTE: use this only for rather noisy sources! For clean ones --> Arad=0.0 (deactivated)

# sharpness	= 80	# internal sharpening of compensated frames: range 0 - 100
# show		= 0	# 1 --> show analyzer clip (interleaved with input)				
			#  2 --> show compensated clip
			#  22 --> show compensated clip / with motion vectors
			#  3 --> show compensated clip (v.stacked with source)
			#  33 --> show compensated clip (v.stacked with source) / with vectors
