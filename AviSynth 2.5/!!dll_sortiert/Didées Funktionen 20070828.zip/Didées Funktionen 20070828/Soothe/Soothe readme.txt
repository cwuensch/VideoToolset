========
 Soothe
========
===
required plugins:

Soothe_MT2.avs:
mt_masktools.dll -> http://manao4.free.fr

===
default call:

dull   = last
sharp  = dull.Sharpener

Soothe(sharp, dull, keep=25)

===
description:

Soothe is a small postprocessor function for sharpening filters. The goal is temporal stabilization of clips that have been sharpened before. It is reasonably fast (contains 3 different YV12Lutxy operations and one TemporalSoften - that's about the cheapest possibility for what is done. Plugin coders are welcome), and seems to work pretty well.

The introduction of jitter on the temporal axis is a general problem of sharpening operations, since sharpening (usually) considers spatial aspects only. Therefore, Soothe() does a very simple job: get the difference between [source] and [sharpened source], apply a TemporalSoften on this difference BUT allow only changes towards 128 ("neutral"), and then apply this temporally calmed difference back to the original clip.
Effectively, this will reduce the overall effect of sharpening - less in static areas, and more in moving areas.

Advantages:

- more steady appearance (less "nervous")
- less bitrate required
- somewhat positive effect on detail that is, due to the sharpening, prone to aliasing
- smoother motion compaired to plain-sharpening, since motion-blurred edges will be less sharpened
- less artefacts in moving areas
- LimitedSharpen can run faster, since one can get away with less supersampling
- should only help, never harm

Disadvantages:

- overall sharpening effect is reduced, but this can be compensated by a little more initial sharpening.


Syntax:

Soothe( [sharpclip], [sourceclip], keep )

"keep" is an integer, range 0 - 100, that tells how much percent of the original sharpening will be kept at least. Default is 25.


Example:

We use LimitedSharpen() as sharpener, and we'll keep at least 20% of its result:


dull   = last
sharp  = dull.LimitedSharpen( ss_x=1.25, ss_y=1.25, strength=150, overshoot=1 )

Soothe( sharp, dull, 20 )