=========
 Ylevels
=========
===
required plugins:

Masktools.dll -> http://manao4.free.fr/MaskTools-v1.5.8.zip
===
description:

Lately, the discussion about the different gamma curves of TV sets and PC monitors came up again. This reminded me of some gamma tricks I'm used to occasionally apply in image processing. And now I even found time set it up in Avisynth

The most-faced problem is: video appears "too dark" on PC monitors.
The usual solution is: raise black level, or slope-up the gamma curve.

Both make the details in very dark areas better visible - but both create the usual ugly "washed-out" effect at the same time.

A more pleasing solution is, to adjust the gamma curve for dark areas more strongly than for bright areas.

All functions are called the same way as AviSynth's "levels()" command, except for the coring parameter. Coring is not available with the Ylevels() functions. They'll always work on the full [0,255] value range.

Ylevels() is a simple replacement for Avisynth's internal levels() command, with a few neat differences:

- processes only luma --> faster, better preservation of color saturation
- no clipping: Ylevels(40,1.0,220, 40, 220) will not clip the output to [40,220] as levels() does. Values below 40 / above 220 will be scaled accordingly to the correct vales. This means, one can use any values for IN_LOW, IN_HIGH as "control points" without getting the input clipped at those values.


But that's not the deal.


YlevelsG() and YlevelsS() apply the given levels conversion by 100% @ Luma==0, by 0% @ Luma=255, and accordingly in-between.

YlevelsG() does a linear sweep (G = Gradient)
YlevelsS() does a sine sweep (S = yes, exactly )

Try those with gamma values 1.5 ~ 4.0. I suppose some will like them.

YlevelsG (not YlevelsS) does "inverse" scaling for gamma values < 1.0, but that's not that great. It's just for completeness.


But that's not all, yet.


While building the LUT expression for the sine sweep , at one point I accidentially swapped some things, and the result was ...

YlevelsC()

For this one, 2.0 < gamma < 16.0 is reasonable.

No, I won't explain it - just try & enjoy it 


Closing comment:

If these functions should be used for encoding or not, depends on the source. I would be carefully, at least ...

But:

These functions are pretty fast! (Manao: thankyouthankyouthank...)
- So they can be nicely used in the "Avisynth" section of ffdshow ...


Have fun
