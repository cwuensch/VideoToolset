============
 PoorDeHalo
============
===
required plugins:

Repair.dll from RemoveGrain 0.9 (!) -> www.RemoveGrain.de.tf
===
default call:

PoorDeHalo(rx=2.5, ry=2.5, str=0.6, chroma=false)
===
description:

not available
===
parameters:

coming sometime