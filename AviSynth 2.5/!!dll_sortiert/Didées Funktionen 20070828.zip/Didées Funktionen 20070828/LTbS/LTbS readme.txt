======
 LTbS
======
===
required plugins:

Masktools.dll -> http://manao4.free.fr/MaskTools-v1.5.8.zip
RemoveGrain.dll from RemoveGrain 1.0 pre -> http://home.arcor.de/kassandro/RemoveGrain/RemoveGrain.rar
Repair.dll from RemoveGrain 0.9 (!) -> www.RemoveGrain.de.tf
===
default call:

LTbS(nr=3, fr=1, mode=2, _uv=3)
===
description:

not available
===
parameters:

not available