=========
 SPresso
=========
===
required plugins:

Masktools.dll -> http://manao4.free.fr/MaskTools-v1.5.8.zip
RemoveGrain.dll of RemoveGrain 1.0 pre -> http://home.arcor.de/kassandro/RemoveGrain/RemoveGrain.rar
===
default call:

SPresso(limit=2, bias=25, RGmode=4)
===
description:

not available
===
parameters:

not available