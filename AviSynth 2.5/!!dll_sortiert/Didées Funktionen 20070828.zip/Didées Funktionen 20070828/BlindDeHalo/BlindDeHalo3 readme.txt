==============
 BlindDeHalo3
==============
===
required plugins:

BlindDeHalo3_mt2:
mt_masktools.dll -> http://manao4.free.fr
RemoveGrain.dll from RemoveGrain 1.0 pre -> http://home.arcor.de/kassandro/RemoveGrain/RemoveGrain.rar
===
default call:

BlindDeHalo3( rx=3.0, ry=3.0, strength=125, 
 \            lodamp=0.0, hidamp=0.0, sharpness=0.0, tweaker=0.0,
 \            PPmode=0, PPlimit=0, interlaced=false)
===
description:

Basically, it does the same as the 2nd version did. New are some tweaking possibilities (partly backported from BDH's initial version), an optional "postprocessing" mode, and ... better performance.

Feeding a cropped 720*432 DVD source, my Athlon XP1800 renders like this:

BDH2: ~10 fps
BDH3: ~25 fps (without PP)

I hope there are no objections against this minor performance increase

With PP activated, the performance gain is smaller: ~13 fps in above example. Also, I'm not yet really satisfied with the PP mode. But it may come handy in its current state already, and I don't want to keep that speedy version back from you, just because of that.

Let's start with parameters and explanations. The function comes at the end, as usual.

Full function call with default values:
Code:

BlindDeHalo3( rx=3.0, ry=3.0, strength=125, 
 \            lodamp=0.0, hidamp=0.0, sharpness=0.0, tweaker=0.0,
 \            PPmode=0, PPlimit=0, interlaced=false)


Parameter description

rx, ry [float]
The radii to use for the [quasi-] gaussian blur, on which the halo removal is based..

strength [int]
The overall strength of the halo removal effect.

lodamp, hidamp [float] (range: 0.0 ~ ??? / try 4.0 as a start)
With these two values, one can reduce the basic effect on areas that would change only little anyway (lodamp), and/or on areas that would change very much (hidamp).
lodamp does a reasonable job in keeping more detail in affected areas.
hidamp is intended to keep rather small areas that are very bright or very dark from getting processed too strong. Works OK on sources that contain only weak haloing - for sources with strong oversharpening, it should not be used, mostly.
(Usage has zero impact on speed.)

sharpness [float] (range: 0.0 ~ 1.58)
By setting this bigger than 0.0, the affected areas will come out with better sharpness. However, strength must be chosen somewhat bigger as well, then, to get the same effect than without.
(This is the same as initial version's "maskblur" option.)

tweaker [float] (range: 0.0 ~ 1.0)
May be used to get a stronger effect, seperately from altering "strenght".
(Also in accordance to initial version's working methodology. I had no better idea for naming this parameter.)

interlaced [bool]
As formerly, this is intended for sources that were originally interlaced, but then made progressive by deinterlacing. It aims in particular at clips that made their way through Restore24.

PPmode [int]
When set to "1" or "2", a second cleaning operation after the basic halo removal is done. This deals for
a) removing/reducing those corona lines that sometimes are left over by BlindDeHalo
b) improving on mosquito noise, if some is present.

PPmode=1 uses a simple gaussian blur for post-cleaning. PPmode=2 uses a 3*3 average, with zero weigthing of the center pixel.

Also, PPmode can be "-1" or "-2". In this case, the main dehaloing step is completely discarded, and *only* the PP cleaning is done. This has less effect on halos, but can deal for sources containing more mosquito noise than halos.

PPlimit [int]
Can be used to make the PP routine change no pixel by more than [PPlimit].
I'm not sure if this makes much sense in this context. However the option is there - you never know what it might be good for.


Comments & tips

Well, I just fiddled it together and checked that everything is working ... there's not very much practical experience yet I can share with you, about the new stuff. However:

- All that PP stuff isn't yet optimized. But it's difficult to make that part noticeably smarter without an aching slowdown, I fear. Try it, share your opinions. Make suggestions.

- Regarding "strength" & "sharpness" & "tweaker"
These three behave somewhat similar, but not the same.
A bigger value for "sharpness" is similar to reducing "strength". A bigger value for "tweaker" is similar to increasing "strength" value -- and vice versa for both.
Also the other way round: when increasing "sharpness", you probably have to increase "strength" a little as well, to get the same removal effect.
Usage of "sharpness" works in particular good when bigger radii (say, >2.5) are used for dehaloing. Usage of "tweaker" is more useful when working with sources containing thin, weak halos.
In the end, it comes down again to try&error

- lodamp and hidamp
Technically, these two are the "n" constants in two scaling factors of the form "x/(x+n)", which are used when creating a LUT from the difference between input clip and its gaussian blurred version.

As described above, "lodamp" deals for better protection of areas where this difference is alredy small. Effectively, it preserves some more of weak detail in areas of high contrast. A value of 4.0 seems a good starting point. One can also try to use bigger values like 16.0 or so, along with a bigger "strength" value. By this, one can somewhat change the characteristics of "what-is-processed-how-strongly" (if I can say so).

"hidamp" tries to do the opposite: protect small detail that is very bright or very dark from being toned down too much. But its usability is much more restricted: it seems to work OK when the actual halos of the source are rather weak, and/or when not too small radii are used - in this case, the protection of very prominent detail works out, mostly.
In case the source contains strong haloing, is's better to not use "hidamp" at all: in this case, the halos itself would be considerd to be "prominent detail" and be protected ... no go.


I think this is close to a "final" version of BlindDeHalo (without a number in the name )


The function script is attached to this post, and will show up upon approval. For reference, the script is posted below.

Have fun!