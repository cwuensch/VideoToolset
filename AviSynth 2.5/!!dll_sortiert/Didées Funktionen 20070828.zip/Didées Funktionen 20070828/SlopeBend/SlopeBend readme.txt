====================
 SlopeBend_v01a.avs
====================
===
required plugins:

Masktools.dll -> http://manao4.free.fr/MaskTools-v1.5.8.zip
===
default call:

SlopeBend(ss_x=1.0, ss_y=1.0, strength=100, overshoot=1, radius=2, soft=false)
===
description:

A sharpening experiment by Did�e. Usage is NOT RECOMMENDED.
It sharpens the picture by adjusting the slope of the gradient values inbetween the local min/max interval. 
Effectively, edges are sharpened without oversharpening (halos) (but risk to make them jaggy).
===
parameters:

# ss_x,ss_y: If needed, the filter may work supersampled. Generally it's not needed, but comes handy for 
#            "uneven" sharpening like i.e. resizing 1:1 PAR --> anamorphic PAR, or for strength values > 100.
# strength:  Not really usable yet - leave at '100'. Bigger gives jagged artefacts, smaller gives ... an interesting effect.
# overshoot: not yet implemented
# radius:    The distance to search for the current pixel's upper & lower boundary. 
#            The bigger, the stronger the effect, but the slower the script runs.
#            range: 1-5 / default: 2
# soft:      Pre-blurring before searching local maxima & minima. Not very useful.
