===========
 ZoomInOut
===========
===
required plugins:

none
===
default call:

ZoomInOut( 100,600, 50,75, 56,0,56,80 )
===
description:

not available
===
parameters:

start=?
end=?
fade_in=?
fade_out=?
x0=?
y0=?
x1=?
y1=?