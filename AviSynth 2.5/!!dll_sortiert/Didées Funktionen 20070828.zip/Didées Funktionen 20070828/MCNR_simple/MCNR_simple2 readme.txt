
============================
 ReadMe  of  MCNR_simple2()  
============================
---
required plugins:

MVTools -> http://www.avisynth.org/fizick/mvtools/
Repair.dll from RemoveGrain 0.9 (!) -> www.RemoveGrain.de.tf
TTempSmooth -> http://www.missouri.edu/~kes25c/
RemoveDirt -> http://www.RemoveDirt.de.tf/  (the "old" DLL-filter!)
---
default call:

MCNR_simple2( frames=2, thY=8, thC=6, thY2=-1, thC2=-1,
 \            blocksize=16, chroME=false, repairME=true, removdirt=false,
 \            LPrad=0.0, LPlosens=1, LPhisens=5 )
---
description:

coming sometime

---
parameters:

# frames    = default( 2 )  #  number of temporal neighbors to use for motion compensation & temporal filtering
# thY       = default( 8 )  #  upper thresh for pixel differences to include into temporal filtering
# thC       = default( 6 )  #  ditto, for chroma
# thY2      = default( -1 )  #  lower diff. thresh, for TTempSmooth (= -1 --> use TemporalSoften, not TTempSmooth)
# thC2      = default( -1 )  #  ditto, for chroma
# blocksize = default( 16 )  #  blocksize for motion search & compensation
# removdirt = default( false)  #  additionally use RemoveDirt? (tip: for strong noise - true, else false. Requires frames>1)
# chroME    = default( false)  #  include chroma planes into motion search?
# repairME  = default( true )  #  simple repairing of MC/ME errors (good when using bigger thresh's).
# LPrad     = default( 0.0 )  #  Lowpass protection: radius for gaussian blur
# LPlosens  = default( 1 )  #  LP protection: lower thresh for motion recognition
# LPhisens  = default( 5 )  #  LP protection: upper thresh for motion recognition

---

examples ...
-----------------------

... weak noisy ("clean" DVD-source), fast : 

MCNR_simple2( frames=1, thY=5, thC=4, blocksize=8, chroME=true, repairME=true)


... heavy Grain, slow: 

MCNR_simple2( frames=3, thY2=20, thC2=12, thY=3, thC=2,
 \            blocksize=16, chroME=false, repairME=true, removdirt=true,
 \            LPrad=2.5, LPlosens=2, LPhisens=6 )



... or completely different, just try.