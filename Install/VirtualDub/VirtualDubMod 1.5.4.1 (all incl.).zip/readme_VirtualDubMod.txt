VirtualDubMod 0.1alpha by Belgabor, Pulco-Citron and Suiryc.

- Based on the fabolous VirtualDub 1.4.10 by Avery Lee (http://www.virtualdub.org)
- Merged from VirtualDubAVS(Belgabor), VirtualDubMPeg2(Pulco-Citron) and VirtualDubOGM(Suiryc)
- Includes the sync patch by Andreas Dittrich (http://www-user.rhrk.uni-kl.de/~dittrich/sync/)
- Includes source code from AVISynthesizer by Warren Young (http://tangentsoft.net/video/asynther/)

Note: I'm not very good with readmes, so don't expect too much.

Disclaimer: THIS IS ALPHA SOFTWARE, SO I WON'T BE HELD RESPONSIBLE FOR ANY DAMAGE DONE BY IT!
(This statement is also included in the GPL)

For features and some hints how to use them see our realease notes.

If you have questions, comments, bug reports,... see our project webpage at http://virtualdubmod.sourceforge.net