Installation:
-------------

1.) Copy the executable "VirtualDub_Sync.exe" in your existing 
    VirtualDub directory.

2.) In VirtualDub capture modus go to menu "Capture->Timing" and select the sync modus.
    When using mode 1 together with a compressed audio-format, mode 2 is applied (see statusline).

[optional but recommended]
3.) Go to menu "Capture->Settings" and set the audiobuffer-size to 
    36000 (for 16bit stereo) or 18000 (for 16bit mono)
