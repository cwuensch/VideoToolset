AVISynthesizer - A tool to make Avisynth usable by mere mortals :)
~~~~~~~~~~~~~~

Intro
~~~~~
    Avisynth is a powerful video processing tool by Ben Rudiak-Gould.
    AVISynthesizer lets you build Avisynth scripts based on predefined
    templates.  If you aren't the sort that is willing or able to learn
    a computer scripting language, AVISynthesizer makes Avisynth's power
    accessible to you.

    If you already know the Avisynth scripting language, AVISynthesizer
    helps you with repetitive scripting chores.  If you have a suitable
    template defined, AVISynthesizer can build complete scripts
    for you.  At the very least, you can use the simple AVISource or
    DirectShowSource templates to generate the repetitive parts that
    begin nearly all one-off scripts.


Installation
~~~~~~~~~~~~
    If you downloaded and ran the AVISynthesizer self-installing package,
    it set AVISynthesizer up for you.

    If you have built AVISynthesizer from source and now want to install
    it manually, run asynther.exe with the -i command line switch.  If you
    are not using Windows 2000 or Windows XP, you will also need to run
    the shfolder.exe program that came with the package.  This installs
    a compatibility DLL that lets my program use a certain Windows 2000
    function on older OSes.
    
    If for some unfortunate reason you want to manually uninstall the
    package, run asynther.exe with the -u switch.  You can also use
    Windows' Add/Remove Programs function to automatically remove the
    program, of course.


Usage
~~~~~
    Right-click on a media file in Explorer, and say "Send to |
    AVISynthesizer".  A small window will pop up listing the available
    Avisynth script templates by description.  Pick one, and hit the
    Generate Script button.  AVISynthesizer will spit out a script named
    after the first file name on the command line and the file name of
    the template you selected.  If there is already a file by that name,
    a number will be appended.  
    
    For example, if you pass foo.avi to AVISynthesizer and select the
    svcd.avst template ("Resize and remove noise for SVCD"), the generated
    script will be named foo--svcd.avs.  If you did the same thing again,
    the next generated script would be named foo--svcd2.avs.

    If you send more than one file to AVISynthesizer, another list
    appears to the right of the template list containing the file
    names you selected.  The arrow buttons to the right of that list
    let you reorder the file list, thus affecting the order they're
    named in the generated Avisynth script.  This feature is necessary
    because, in certain situations, Explorer passes the selected files to
    AVISynthesizer in an odd order.  Rather than force users to Ctrl-Click
    each file individually to set the order, I added this feature.


Template Syntax
~~~~~~~~~~~~~~~
    AVISynthesizer comes with several sample templates, all of which are
    useful, to various degrees.  If you want to make your own templates,
    you need to know Avisynth's scripting language and the AVISynthesizer
    template rules:

        0. The script must contain a specially-formatted comment.  See
           the exmple below for details.

        1. The first instance of the string "%f" (without the quotes) is
           replaced with the file name given on the asynther.exe command
           line.

        2. If you put a section of the script in [square brackets],
           that section will be repeated once for each file name
           passed on the command line.  Within that repeating section,
           the %f is replaced with a file name from the command
           line, and a plus sign is placed between each repeated
           script section.

        3. The template must be placed in a subdirectory called
           template underneath the directory where you put
           asynther.exe.  Each template file must end in .avst.

    The effect of these rules is clearer with an example.  Consider
    this simple AVISynthesizer template:

        #ASYNTHER Just a simple template
        [AVISource("%f")]

    If you run asynther.exe with "1" as the command line argument,
    it will generate a file called 1.avs:

        #ASYNTHER Just a simple template
        AVISource("1")

    If you run asynther.exe with "1 2" as the command line arguments,
    it will generate a file called 1.avs:

        #ASYNTHER Just a simple template
        AVISource("1") + AVISource("2")

    Notice that AVISynthesizer names the output script after the
    first input file name.
        
    The "Just a simple template" on the ASYNTHER comment line is used by
    AVISynthesizer to build the list box you see on startup, letting you
    pick a template by description.


Limitations
~~~~~~~~~~~
    o  If you set up a repeating section in a script template, there
       must be a "%f" somewhere within that repeating section.
       AVISynthesizer will yell at you if you violate this rule.  If you
       have a good reason to violate this rule, email me about it.  If
       you come up with useful behavior for this situation, I'll probably
       implement it.

    o  The program only understands one repeating section per line, and
       it does not understand nested repeating sections.  If there
       is more than one set of brackets on a line, it will use the
       outside-most pair.

    o  The closing bracket for a repeating section must be on the same
       line as the opening bracket.


Addresses
~~~~~~~~~
    Author's email:      Warren Young <wdyoung@acm.org>
    AVISynthesizer home: http://www.cyberport.com/~tangent/video/asynther.html
    Avisynth home:       http://www.math.berkeley.edu/~benrg/avisynth.html

